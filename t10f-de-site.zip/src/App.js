import { useState } from "react";

export default function App() {
  const [page, setPage] = useState("home");

  return (
    <main className="min-h-screen bg-white text-gray-900 p-6 max-w-5xl mx-auto">
      <nav className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold cursor-pointer" onClick={() => setPage("home")}>T10F.DE</h1>
        <div className="space-x-4">
          <button onClick={() => setPage("home")} className="text-blue-600 hover:underline">Ana Sayfa</button>
          <button onClick={() => setPage("blog")} className="text-blue-600 hover:underline">Blog</button>
        </div>
      </nav>

      {page === "home" && (
        <section>
          <h2 className="text-2xl font-semibold mb-4">Yapay Zeka Araçları ile Tanışın</h2>
          <p className="mb-6 text-lg">T10F.DE, yaratıcı AI çözümlerini herkes için erişilebilir kılar. Yazı yazın, görseller oluşturun, ses sentezi deneyin.</p>
          <div className="grid md:grid-cols-2 gap-4">
            <Tool title="AI Yazı Üretici" desc="Metin içerikleri saniyeler içinde yazın." />
            <Tool title="Görsel Üretici" desc="AI ile benzersiz görseller üretin." />
            <Tool title="Ses Sentezleyici" desc="Metni gerçekçi sese çevirin." />
            <Tool title="Blog" desc="Yapay zeka haberlerini ve içerikleri keşfedin." />
          </div>
        </section>
      )}

      {page === "blog" && (
        <section>
          <h2 className="text-2xl font-semibold mb-4">Yapay Zeka Çağında Yeni Nesil Dijital Araçlar</h2>
          <article className="space-y-4 text-base leading-relaxed">
            <p>2025 yılı, yapay zekânın günlük hayatımıza entegre olduğu bir dönüm noktası oldu. Metin üretiminden görsel sanata, ses sentezinden analiz araçlarına kadar sayısız uygulama, bireylerin ve işletmelerin çalışma biçimini dönüştürüyor. T10F.DE, bu dönüşümün merkezine konumlanmak için kuruldu.</p>
            <p>T10F.DE, modern dijital araçları herkesin kullanımına açmayı hedefleyen bir teknoloji platformudur. Amacımız, kullanıcıların ilham verici içerikler üretmesine ve yenilikçi projeler geliştirmesine yardımcı olmaktır.</p>
            <ul className="list-disc list-inside">
              <li><strong>Yapay Zeka Yazarı:</strong> Blog gönderileri, e-postalar, tanıtım metinleri üretin.</li>
              <li><strong>Görsel Üretici:</strong> AI destekli sanat eserleri oluşturun.</li>
              <li><strong>Ses Sentezi:</strong> Gerçekçi metin-okuma deneyimi.</li>
              <li><strong>Otomatik Özetleme:</strong> Uzun içerikleri özetleyin.</li>
            </ul>
            <p>T10F.DE olarak sadece araç sunmakla kalmayacağız. Yakında API erişimi, eğitim içerikleri ve geliştirici ağı da sunacağız.</p>
            <p>Yapay zekâ çağında üretkenlik, sadece zamanla değil, doğru araçlarla ölçülüyor. T10F.DE olarak bu araçları size ulaştırmaktan heyecan duyuyoruz.</p>
          </article>
        </section>
      )}
    </main>
  );
}

function Tool({ title, desc }) {
  return (
    <div className="bg-gray-100 p-4 rounded-2xl shadow-sm hover:shadow-lg transition">
      <h3 className="text-lg font-bold mb-1">{title}</h3>
      <p>{desc}</p>
    </div>
  );
}
